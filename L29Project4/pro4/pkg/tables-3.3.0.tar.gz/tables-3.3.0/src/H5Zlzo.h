#ifndef __H5ZLZO_H__
#define __H5ZLZO_H__ 1

#define FILTER_LZO 305
int register_lzo(char **version, char **date);

#endif /* ! defined __H5ZLZO_H__ */
